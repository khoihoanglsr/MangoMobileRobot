// generated from rosidl_generator_c/resource/idl.h.em
// with input from example_interfaces:msg/WString.idl
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__W_STRING_H_
#define EXAMPLE_INTERFACES__MSG__W_STRING_H_

#include "example_interfaces/msg/detail/w_string__struct.h"
#include "example_interfaces/msg/detail/w_string__functions.h"
#include "example_interfaces/msg/detail/w_string__type_support.h"

#endif  // EXAMPLE_INTERFACES__MSG__W_STRING_H_
